#!/bin/sh
set -e
if [ -z "$TLE_EPOCH" ]; then
  echo "TLE_EPOCH is not stored in this folder. Recover it from signed_cmds.log, then export it." >&2
  exit 1
fi
exec python3 /opt/slew/app.py
