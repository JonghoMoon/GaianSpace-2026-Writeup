#!/usr/bin/env python3
"""Kestrel Array slew authority (fictional, offline).
Slew orders are rejected unless they carry a valid seal. A valid park-to-home
(action=park, angle_deg=0) returns the maintenance token. The token is shipped
only as flag.enc and never stored in the clear."""
import json, os, hmac, hashlib, struct
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

STATION_ID = os.environ.get("STATION_ID", "KESTREL-ARRAY")
TLE_EPOCH  = os.environ["TLE_EPOCH"]              # provisioned at boot
PORT       = int(os.environ.get("PORT", "8000"))
ENC        = os.path.join(os.path.dirname(__file__), "flag.enc")

def key():
    return hashlib.sha256(f"{STATION_ID}:{TLE_EPOCH}".encode()).digest()

def keystream(k, n):
    out = b""; i = 0
    while len(out) < n:
        out += hmac.new(k, b"SLEW-CTR" + struct.pack(">I", i), hashlib.sha256).digest()
        i += 1
    return out[:n]

def flag():
    c = open(ENC, "rb").read()
    ks = keystream(key(), len(c))
    return bytes(a ^ b for a, b in zip(c, ks)).decode("latin-1")

def canon(c): return f"{c['station_id']}|{c['action']}|{c['angle_deg']}|{c['nonce']}"
def sign(c):  return hmac.new(key(), canon(c).encode(), hashlib.sha256).hexdigest()

class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def _s(self,code,o):
        b=json.dumps(o).encode(); self.send_response(code)
        self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path.startswith("/api/health"):
            return self._s(200,{"status":"ok","station":STATION_ID,"auth":"hmac-sha256"})
        self._s(404,{"error":"POST /api/slew {station_id,action,angle_deg,nonce,sig}"})
    def do_POST(self):
        if not self.path.startswith("/api/slew"): return self._s(404,{"error":"not found"})
        n=int(self.headers.get("Content-Length","0"))
        try: c=json.loads(self.rfile.read(n) or b"{}")
        except Exception as e: return self._s(400,{"error":str(e)})
        for f in ("station_id","action","angle_deg","nonce","sig"):
            if f not in c: return self._s(400,{"error":"missing "+f})
        if not hmac.compare_digest(sign(c), str(c["sig"])):
            return self._s(403,{"error":"bad signature"})
        if c["action"]=="park" and int(c["angle_deg"])==0:
            return self._s(200,{"status":"parked","flag":flag()})
        return self._s(200,{"status":"slew accepted","angle_deg":c["angle_deg"]})

if __name__=="__main__":
    print("slew authority on :%d"%PORT); ThreadingHTTPServer(("0.0.0.0",PORT),H).serve_forever()
