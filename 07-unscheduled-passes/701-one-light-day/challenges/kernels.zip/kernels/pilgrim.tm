KPL/MK

Pilgrim-1 meta-kernel. Load this one file.

\begindata
PATH_VALUES     = ( '.' )
PATH_SYMBOLS    = ( 'K' )
KERNELS_TO_LOAD = ( '$K/naif0012.tls'
                    '$K/pilgrim1_sclk_v07.tsc'
                    '$K/pilgrim1_recon_2026.bsp' )
NAIF_BODY_NAME += ( 'PILGRIM-1' )
NAIF_BODY_CODE += ( -901 )
\begintext
